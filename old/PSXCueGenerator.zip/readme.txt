PSXCueGenerator 1.0.0.27718 + Source
Coded by: Shawn M. Crawford [sleepy9090]
December 24, 2017

Requires .NET Framework 3.5
Source can be opened/built with Visual Studio 2013

December 24, 2017 Version 1.0.0.27718
-Generates a cue file for bin files that do not have one.
-Generate a single cue file for a single bin file
-Generate cue files for multiple bin files in a directory or directory tree (recursively).
-Built-in Logger


